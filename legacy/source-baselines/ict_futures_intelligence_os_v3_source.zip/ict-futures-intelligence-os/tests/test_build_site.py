import sys, tempfile, unittest, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import build_site

class BuildSiteTests(unittest.TestCase):
    def test_allowlisted_futures_site_build_contains_runtime_files(self):
        with tempfile.TemporaryDirectory(prefix='ict-futures-site-test-') as td:
            output=Path(td)/'dist'
            build_site.build(output)
            required=['index.html','resources.json','manifest.webmanifest','icon.svg','sw.js','robots.txt','sitemap.xml','data/news-snapshot.json','data/market-universe.json','data/ict-playbook.json','data/ict-academy.json','data/source-directory.json','data/news-queries.json']
            for relative in required: self.assertTrue((output/relative).is_file(),relative)
            self.assertTrue((output/'markets/nq.html').is_file())
            self.assertTrue((output/'markets/btc.html').is_file())
            self.assertEqual(len(list((output/'markets').glob('*.html'))),15)
            self.assertTrue((output/'academy/fvg.html').is_file())
            self.assertTrue('External source references' in (output/'academy/cisd.html').read_text())
            academy=json.loads((ROOT/'data/ict-academy.json').read_text())
            self.assertEqual(len(list((output/'academy').glob('*.html'))),len(academy['concepts']))
            self.assertTrue((output/'academy/cisd.html').is_file())
            self.assertTrue((output/'academy/ict-2022-model.html').is_file())
            self.assertFalse((output/'README.md').exists())
            self.assertFalse((output/'scripts').exists())

    def test_futures_universe_is_scoped_and_tiered(self):
        data=json.loads((ROOT/'data/market-universe.json').read_text())
        self.assertEqual(data['count'],15)
        tiers={t:sum(1 for m in data['markets'] if m['tier']==t) for t in ('T1','T2','T3')}
        self.assertEqual(tiers,{'T1':5,'T2':4,'T3':6})
        self.assertTrue(all(m.get('specsUrl','').startswith('https://') for m in data['markets']))
        self.assertTrue(all(m.get('tickSize',0)>0 and m.get('tickValue',0)>0 for m in data['markets']))

if __name__=='__main__': unittest.main()
