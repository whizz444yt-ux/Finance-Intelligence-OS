# Changelog

## 3.0.0 — 2026-11-08

- Added sticky top navigation with contract selector and dedicated Daily Brief, Charts, ICT Academy, Social Research and Prediction Markets tabs.
- Added an expanded 76-lesson ICT Academy with learning tracks, definitions, practical steps, limitations, related concepts, local completion tracking, original ICT channel/playlists and concept-specific YouTube discovery links, labelled source references and 18 additional supplemental/model lessons. Added a universal search for markets, lessons, sources and tabs.
- Added standalone SEO pages for every lesson and retained the 15 standalone contract pages.
- Added a contract-specific daily intelligence brief from available headline snapshots, dated events and profile context; includes JSON export and explicit source-freshness limitations.
- Expanded the calendar with upcoming list/day/week/month filters, countdown, ET-to-IST display, personal reminders and ICS export.
- Added public Polymarket and Kalshi market discovery panels with read-only best-effort API requests and honest fallback states.
- Expanded public institutional data links for CFTC COT/history/public datasets, Bank Participation, CME volume/open interest, SEC Form 4/8-K/10-Q/10-K/13F, Treasury auctions, FedWatch and expiry calendars.
- Expanded social research discovery for X, LinkedIn, YouTube, Reddit, TradingView, Stocktwits, public Telegram discovery and Discord public-server directory.
- Added journal analytics for recorded R-results: win rate, expectancy, profit factor, average win/loss, max drawdown and breakdowns by contract/model.
- Kept all unrelated finance categories excluded. No private/stolen data, order execution, fabricated predictions or synthetic live prices are added.
- Added build checks for the Academy dataset and generated lesson pages; added the Academy data file to offline shell caching.

## 2.2.0

- Futures-only edition with 15 contract families, session windows, risk calculator, local journal, public-news snapshots and GitHub Pages build.
