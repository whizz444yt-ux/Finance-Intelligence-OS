# ICT Futures Intelligence OS 3.0

A futures-only research and learning workspace built around the supplied **ICT Futures Playbook**. The scope is deliberately limited to 15 futures contract families and their micro references. It is not a broker, execution system, financial adviser or licensed real-time market-data terminal.

## Main workspaces

- **Overview & Daily Brief** — contract-aware digest from the available public-news snapshot, dated event schedule and market profile context. The brief never invents a directional forecast.
- **Markets** — 15 contract families in the PDF's Tier 1 / Tier 2 / Tier 3 grouping, with exchange specifications, sessions, catalysts and comparison relationships.
- **Charts** — TradingView preview where provider embed access permits, direct chart links, related-market shortcuts, CME volume/open-interest and market-depth references.
- **ICT Academy** — 76 concept and model lessons, beginner-to-advanced learning paths, related lesson links, source references, local completion tracking, official ICT channel/playlists and concept-specific YouTube discovery searches. Supplemental community terms are separated from source-derived playbook material.
- **Sessions** — New York-time killzones, session windows, contract heat map and DST-aware ET↔IST conversion.
- **Calendar** — packaged dated source events, contract filtering, next-event countdown, day/week/month views, personal local reminders and ICS export. Open the original issuer calendar to confirm changes and holidays.
- **Newsroom & Social Research** — contract-specific news destinations and public search links for X, LinkedIn, YouTube, Reddit, TradingView, Stocktwits, public Telegram discovery and Discord's public server directory.
- **Institutional & Public Disclosures** — CFTC COT, historical COT, Bank Participation, CME volume/open interest, SEC Form 4 / 8-K / 10-Q / 10-K / 13F search, Treasury auctions, FedWatch and contract-expiry sources.
- **Prediction Markets** — best-effort read-only discovery from Polymarket Gamma and Kalshi public market endpoints. Browser CORS/network restrictions can prevent loading; use provider links as fallback.
- **Risk Lab & Journal** — standard/micro position sizing, fees/slippage allowance, direction checks, local journal, win rate, average R, expectancy, profit factor, drawdown and contract/model breakdowns based on user-entered results.
- **Sources** — curated official, media, API documentation, social and education destinations with access-type labels.

## Data access labels and limitations

The site distinguishes direct official links, public search pages, public API discovery, subscription/paywalled sources, and data requiring a licensed provider. A link to Reuters, Bloomberg, LinkedIn, X or YouTube is not a claim that the website has authenticated or ingested every post/article. Public SEC submissions are linked and documented; the SEC API should be accessed server-side with a compliant user-agent and rate limits. COT and Bank Participation are aggregate reports, not confidential insider feeds.

Polymarket and Kalshi requests are best-effort and can be blocked by browser CORS, provider changes, request limits or local network policy. A failed request is shown as unavailable; no synthetic quote is substituted. Prediction prices are not guaranteed probabilities and do not constitute a trading recommendation.

True real-time CME quotes, market depth, order flow and professional newswires require appropriate licences/subscriptions. Free website quotes can be delayed. The static GitHub Pages edition does not contain API secrets and cannot serve as a secure proxy. For authenticated user accounts, cloud journals, server-side APIs and secure scheduled collectors, add a backend such as Supabase or serverless functions without exposing credentials in browser JavaScript.

## Build locally

Requirements: Python 3.10+; Node.js is recommended for JavaScript syntax checks.

```bash
python scripts/build_html.py
python scripts/build_market_pages.py
python scripts/build_academy_pages.py
python scripts/build_manifest.py
python scripts/validate.py
python -m unittest discover -s tests -v
python scripts/build_site.py --output dist
```

`dist/` is the allow-listed GitHub Pages payload. `index.html` is generated from `src-index.template.html` plus `data/*.json`. Static market pages live in `markets/`; 76 concept lesson pages live in `academy/`.

## News snapshot

`scripts/fetch_news_snapshot.py` collects a best-effort public GDELT news snapshot. It is a discovery aid, not a full newswire or guaranteed hourly service. GitHub scheduled jobs may be delayed or skipped. The news snapshot's retrieval timestamp and status are shown in the UI.

## Trust and evidence rules

- Contract multipliers, tick values, active expiries and schedules must be checked against the current official exchange source before trading.
- PDF-derived material is retained as the primary playbook framing; extra concept explanations are labelled supplemental where appropriate.
- YouTube concept searches are discovery links, not verified one-to-one mappings to original ICT lessons.
- The uploaded playbook reports that several ICT models do not have audited independent public performance statistics. This site does not invent win rates or backtest results.
- Social posts are public opinions; official releases and original sources take priority.
- No hacked, stolen, private or non-public insider information is accessed or surfaced.
- Local journal and lesson-completion records remain in the browser until the user exports them. Clearing browser storage can remove them.

## Project status

Static site source and build tests are included. Browser embeds and external providers must be checked in the deployed environment. The package does not imply a real-time data licence or continuous provider availability.
