# Architecture — ICT Futures Intelligence OS 3.0

## Data flow

`data/*.json` is the reviewed source of truth for the static release. `scripts/build_html.py` embeds the market universe, playbook, curated sources, news snapshot and ICT Academy into `index.html`. `build_market_pages.py` creates 15 contract landing pages; `build_academy_pages.py` creates 76 concept-learning pages and updates the sitemap. `build_site.py` copies an allow-listed payload to `dist/`.

## Browser modules

- Market state is shared across contract selector, chart workspace, newsroom, social research, daily brief, event filter, risk calculator and journal planning.
- ET wall-clock references are converted using `America/New_York` and `Asia/Kolkata` IANA time zones to account for DST.
- Personal event reminders, lesson-completion state, checklist and journal are stored in local browser storage. JSON and ICS exports provide user-controlled backups.
- Public prediction-market discovery calls do not send credentials and are read-only. CORS/network/provider errors produce an explicit unavailable state.
- Institutional filing and positioning areas are link-based in the static edition; official source pages are preferred over scraping arbitrary content.

## Data boundaries

The GDELT snapshot is scheduled best-effort discovery, not full-text Reuters/Bloomberg or a live newswire. TradingView embeds and quotes are provider-dependent. Real-time quotes, market depth, CVD, footprint, DOM, and professional news services require licensed data. Secure API keys, authenticated SEC requests, persistent user accounts, cross-device journals and dependable alert delivery require a backend/server-side collector; never put secrets in `index.html`.

## Quality gates

`validate.py` checks required UI IDs, 15 contract families and tier split, academy schema and 76 generated lesson pages, source uniqueness/protocol, SEO output, checksums and inline JavaScript syntax. Unit tests cover the static build and GDELT snapshot normalization/failure retention. This is static and syntax validation; a live browser review is still required after deployment to verify third-party embeds, API CORS, mobile layout and provider availability.
