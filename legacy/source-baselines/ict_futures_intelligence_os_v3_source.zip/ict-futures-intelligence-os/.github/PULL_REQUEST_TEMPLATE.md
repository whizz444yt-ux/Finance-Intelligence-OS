## What changed?

- 

## Validation

- [ ] `python scripts/validate.py`
- [ ] `python -m unittest discover -s tests -v`
- [ ] `python scripts/build_site.py --output dist`
- [ ] No secret/API token or personal data was added.
- [ ] New source URLs have descriptions, access/licensing notes and are deduplicated.
- [ ] Forecasts are labelled as scenarios and do not claim guaranteed outcomes.
