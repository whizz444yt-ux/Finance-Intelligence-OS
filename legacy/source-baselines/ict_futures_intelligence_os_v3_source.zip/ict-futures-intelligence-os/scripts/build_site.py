#!/usr/bin/env python3
"""Build the allow-listed static payload used by GitHub Pages."""
from pathlib import Path
import argparse, shutil, subprocess, sys
ROOT = Path(__file__).resolve().parents[1]
DEFAULT_FILES = [
    Path('.nojekyll'), Path('index.html'), Path('resources.json'),
    Path('manifest.webmanifest'), Path('icon.svg'), Path('sw.js'),
    Path('robots.txt'), Path('sitemap.xml'),
    Path('data/market-universe.json'), Path('data/ict-playbook.json'), Path('data/ict-academy.json'),
    Path('data/source-directory.json'), Path('data/social-analysis-methods.json'),
    Path('data/news-queries.json'), Path('data/news-snapshot.json'),
]

def run_builders():
    for script in ('build_html.py','build_market_pages.py','build_academy_pages.py'):
        result=subprocess.run([sys.executable,str(ROOT/'scripts'/script)],cwd=ROOT)
        if result.returncode: raise RuntimeError(f'{script} failed')

def build(output: Path) -> None:
    run_builders()
    output = output.resolve()
    if output == ROOT or (ROOT in output.parents and output != (ROOT / 'dist').resolve()):
        raise ValueError('Output must be outside the repository root or exactly its dist/ build directory.')
    if output.exists(): shutil.rmtree(output)
    output.mkdir(parents=True)
    for relative in DEFAULT_FILES:
        source = ROOT / relative
        if not source.is_file(): raise FileNotFoundError(f'Required static site file missing: {relative}')
        target = output / relative; target.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(source, target)
    source_markets=ROOT/'markets'; target_markets=output/'markets'
    if not source_markets.is_dir(): raise FileNotFoundError('Generated markets/ pages are missing')
    shutil.copytree(source_markets,target_markets)
    source_academy=ROOT/'academy'; target_academy=output/'academy'
    if not source_academy.is_dir(): raise FileNotFoundError('Generated academy/ pages are missing')
    shutil.copytree(source_academy,target_academy)
    print(f'Built static site into {output} ({len(DEFAULT_FILES)} root/runtime files + {len(list(target_markets.glob("*.html")))} contract pages + {len(list(target_academy.glob("*.html")))} ICT lesson pages).')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', default='dist', help='Output directory (default: dist)')
    args = parser.parse_args(); build(Path(args.output))
