#!/usr/bin/env python3
"""Generate a self-contained futures-only index.html with embedded research data."""
from pathlib import Path
from datetime import date
import json
ROOT=Path(__file__).resolve().parents[1]

def read(rel): return json.loads((ROOT/rel).read_text(encoding='utf-8'))
def main():
    template=(ROOT/'src-index.template.html').read_text(encoding='utf-8')
    bundle={
      'generatedAt':date.today().isoformat(),
      'markets':read('data/market-universe.json')['markets'],
      'playbook':read('data/ict-playbook.json'),
      'sources':read('data/source-directory.json')['sources'],
      'snapshot':read('data/news-snapshot.json'),
      'academy':read('data/ict-academy.json'),
    }
    packed=json.dumps(bundle,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
    if '__DATA_BUNDLE__' not in template: raise SystemExit('Data bundle marker is missing from template.')
    output=template.replace('__DATA_BUNDLE__',packed)
    (ROOT/'index.html').write_text(output,encoding='utf-8')
    print(f"Built index.html ({len(output.encode('utf-8')):,} bytes) with {len(bundle['markets'])} contract families and {len(bundle['sources'])} sources and {len(bundle['academy']['concepts'])} ICT lessons.")
if __name__=='__main__': main()
