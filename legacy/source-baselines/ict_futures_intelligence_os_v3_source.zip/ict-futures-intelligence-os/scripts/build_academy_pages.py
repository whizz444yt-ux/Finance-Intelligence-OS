#!/usr/bin/env python3
"""Generate indexable standalone lesson pages for every curated ICT concept."""
from pathlib import Path
import json, html
ROOT = Path(__file__).resolve().parents[1]
BASE = 'https://whizz444yt-ux.github.io/new.w'

def esc(v): return html.escape(str(v or ''), quote=True)
def reference_link(r):
    url = r.get('url', '')
    if not str(url).startswith('https://'):
        return ''
    label = r.get('name') or r.get('type') or 'Reference'
    return f'<a href="{esc(url)}" target="_blank" rel="noopener noreferrer">{esc(label)} ↗</a>'

def main():
    academy = json.loads((ROOT/'data/ict-academy.json').read_text(encoding='utf-8'))
    pages = ROOT/'academy'; pages.mkdir(exist_ok=True)
    ids = {c['name']:c['id'] for c in academy['concepts']}
    for c in academy['concepts']:
        title = f"{c['name']} — ICT Futures Academy | ICT Futures Intelligence OS"
        desc = f"Learn {c['name']} in the ICT futures framework: definition, how to identify it, practical use, common mistakes, evidence limits and related lessons."
        related = ''.join(f'<a class="chip" href="{esc(ids[n])}.html">{esc(n)} →</a>' if n in ids else f'<span class="chip">{esc(n)}</span>' for n in c.get('related',[]))
        references = ''.join(reference_link(r) for r in c.get('referenceLinks',[]))
        steps = ''.join(f'<li>{esc(x)}</li>' for x in c.get('howToUse',[]))
        html_doc = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)}</title><meta name="description" content="{esc(desc)}"><meta name="keywords" content="ICT futures, {esc(c['name'])}, ICT trading concepts, futures education"><meta name="robots" content="index,follow"><link rel="canonical" href="{BASE}/academy/{esc(c['id'])}.html"><meta property="og:type" content="article"><meta property="og:title" content="{esc(title)}"><meta property="og:description" content="{esc(desc)}"><meta name="theme-color" content="#102339"><style>body{{margin:0;background:#f3f6fa;color:#172a3d;font:15px/1.65 system-ui,sans-serif}}main{{max-width:900px;margin:32px auto;padding:0 18px}}.hero,section{{background:#fff;border:1px solid #dce5ee;border-radius:15px;padding:22px;margin:14px 0}}.hero{{background:linear-gradient(120deg,#102339,#176a7b);color:#fff}}h1{{font-size:clamp(25px,5vw,38px);line-height:1.12;margin:10px 0}}h2{{font-size:18px;margin:0 0 10px}}p,li{{color:#617487;font-size:14px}}.hero p{{color:#d5e4ef}}a{{color:#276aa6}}.links,.related{{display:flex;gap:8px;flex-wrap:wrap}}.links a,.chip{{display:inline-block;background:#edf3f8;border-radius:8px;padding:8px 10px;font-size:12px;font-weight:700;text-decoration:none}}.tag{{display:inline-block;padding:4px 8px;border-radius:6px;background:#e8f3f4;color:#0d746b;font-size:10px;font-weight:800}}.callout{{border-left:3px solid #178b8a;background:#f1f7f8;padding:12px;border-radius:8px;color:#426175;font-size:13px}}footer{{color:#627488;font-size:11px;padding:20px}}@media(max-width:600px){{main{{margin:18px auto}}.hero,section{{padding:16px}}}}</style><script type="application/ld+json">{{"@context":"https://schema.org","@type":"LearningResource","name":"{esc(c['name'])}","description":"{esc(desc)}","learningResourceType":"Lesson","educationalLevel":"{esc(c['level'])}","inLanguage":"en"}}</script></head><body><main><header class="hero"><span class="tag">{esc(c['category'])} · {esc(c['level'])}</span><h1>{esc(c['name'])}</h1><p>{esc(c['definition'])}</p><div class="links"><a href="../index.html#academy">Open interactive ICT Academy →</a><a href="https://www.youtube.com/@InnerCircleTrader" target="_blank" rel="noopener noreferrer">Official ICT channel ↗</a><a href="https://www.youtube.com/@InnerCircleTrader/playlists" target="_blank" rel="noopener noreferrer">Official playlists ↗</a></div></header><section><h2>How to identify and use this concept</h2><ol>{steps}</ol><div class="callout">{esc(c.get('useCase','Use only when the setup conditions and invalidation are clearly defined.'))}</div></section><section><h2>Common mistakes and limitations</h2><p>{esc(c.get('commonMistakes','Do not use this concept in isolation or change rules after seeing results.'))}</p></section><section><h2>Evidence and source note</h2><p><strong>{esc(c.get('evidence','CONVENTION'))}</strong></p><p>{esc(c.get('sourceNote','Supplemental lesson note. Verify original definitions and maintain consistent rules.'))}</p></section><section><h2>External source references</h2><p>References are labelled as official, secondary or community material in the interactive academy. Supplemental terminology may vary across educators.</p><div class="links">{references or '<span>No external reference is mapped; see the source note.</span>'}</div></section><section><h2>Learn from YouTube</h2><p>Start with the official ICT channel and playlists. The concept-specific search is a discovery link; it does not claim an individual video has been verified as the official source lesson.</p><div class="links"><a href="{esc(c.get('officialChannel',academy.get('officialChannel')))}" target="_blank" rel="noopener noreferrer">Official channel ↗</a><a href="{esc(c.get('officialPlaylists',academy.get('officialPlaylists')))}" target="_blank" rel="noopener noreferrer">Official playlists ↗</a><a href="{esc(c.get('videoSearch'))}" target="_blank" rel="noopener noreferrer">Search {esc(c['name'])} lessons ↗</a></div></section><section><h2>Related concepts</h2><div class="related">{related or '<span>No related lessons have been mapped.</span>'}</div></section><footer>Educational material only; not investment advice or a trade signal. Futures are leveraged and can cause substantial losses. <a href="../index.html">Return to ICT Futures Intelligence OS</a>.</footer></main></body></html>'''
        (pages/f"{c['id']}.html").write_text(html_doc, encoding='utf-8')
    # Preserve all contract SEO URLs and add the concept lesson URLs.
    market_data = json.loads((ROOT/'data/market-universe.json').read_text(encoding='utf-8'))
    urls = [BASE+'/', *[BASE+f"/markets/{m['id']}.html" for m in market_data['markets']], *[BASE+f"/academy/{c['id']}.html" for c in academy['concepts']]]
    (ROOT/'sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+''.join(f'<url><loc>{esc(u)}</loc></url>' for u in urls)+'</urlset>\n',encoding='utf-8')
    print(f"Generated {len(academy['concepts'])} ICT concept SEO pages and updated sitemap ({len(urls)} URLs).")

if __name__ == '__main__': main()
