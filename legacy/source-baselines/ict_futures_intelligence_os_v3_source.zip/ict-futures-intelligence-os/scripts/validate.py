#!/usr/bin/env python3
"""Offline integrity checks for ICT Futures Intelligence OS. No network needed."""
from pathlib import Path
from html.parser import HTMLParser
import hashlib, json, re, shutil, subprocess, sys, tempfile
ROOT = Path(__file__).resolve().parents[1]

class Checker(HTMLParser):
    def __init__(self):
        super().__init__(); self.ids=[]; self.links=[]; self.title=''; self.in_title=False; self.scripts=[]; self.in_script=False; self.script_attrs={}; self.script_buf=[]
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if 'id' in a: self.ids.append(a['id'])
        if tag=='a' and a.get('href') is not None: self.links.append((a.get('href',''),a.get('target'),a.get('rel','')))
        if tag=='title': self.in_title=True
        if tag=='script': self.in_script=True; self.script_attrs=a; self.script_buf=[]
    def handle_endtag(self, tag):
        if tag=='title': self.in_title=False
        if tag=='script' and self.in_script:
            self.scripts.append((self.script_attrs,''.join(self.script_buf))); self.in_script=False
    def handle_data(self,data):
        if self.in_title: self.title += data
        if self.in_script: self.script_buf.append(data)

def fail(msg): print('FAIL:',msg); return False

def main():
    ok=True
    html_path=ROOT/'index.html'; html=html_path.read_text(encoding='utf-8')
    parser=Checker(); parser.feed(html); parser.close()
    if 'ICT Futures Intelligence OS' not in parser.title: ok=fail('missing/incorrect HTML title') and ok
    duplicates=sorted({x for x in parser.ids if parser.ids.count(x)>1})
    if duplicates: ok=fail('duplicate IDs: '+', '.join(duplicates)) and ok
    idset=set(parser.ids)
    broken_hashes=sorted({h for h,_,_ in parser.links if h.startswith('#') and h[1:] not in idset})
    if broken_hashes: ok=fail('broken internal anchors: '+', '.join(broken_hashes)) and ok
    required=['top','dashboard','daily-brief','briefMarket','briefHorizon','briefNews','briefEvents','markets','marketGrid','market-profile','profileSelect','globalMarket','sessions','sessionGrid','heatTable','charts','chartMarket','tvChartFrame','crossMarketCards','academy','academyTracks','academySearch','academyConceptGrid','academyDetail','playbook','conceptGrid','modelGrid','calendar','eventGrid','calendarView','nextEventCountdown','manualEventList','news','newsLinks','social','socialLinks','positioning','positionCards','predictions','polyList','kalshiList','risk','riskMarket','riskContracts','journal','journalAnalytics','checklist','journalList','sources','sourceGroups','themeToggle','globalSearch','globalSearchResults','academyLessonTotal','calculateRisk','riskDirection','riskEntry','riskStop','riskTarget']
    missing=[x for x in required if x not in idset]
    if missing: ok=fail('missing expected UI IDs: '+', '.join(missing)) and ok
    if 'directionValid' not in html or 'selected Long/Short direction' not in html: ok=fail('risk calculator must validate stop/target against trade direction') and ok
    bad=[h for h,t,r in parser.links if t=='_blank' and ('noopener' not in r and 'noreferrer' not in r)]
    if bad: ok=fail(f'{len(bad)} target=_blank links lack noopener/noreferrer') and ok
    for href,_,_ in parser.links:
        if href.lower().startswith(('javascript:','data:','vbscript:')): ok=fail('unsafe href scheme: '+href[:100]) and ok

    markets_data=json.loads((ROOT/'data'/'market-universe.json').read_text(encoding='utf-8'))
    markets=markets_data.get('markets',[])
    if markets_data.get('count')!=len(markets): ok=fail('market-universe count mismatch') and ok
    if len(markets)!=15: ok=fail(f'expected 15 core futures families; found {len(markets)}') and ok
    expected={'T1':5,'T2':4,'T3':6}
    counts={t:sum(1 for m in markets if m.get('tier')==t) for t in expected}
    if counts!=expected: ok=fail(f'incorrect tier distribution: {counts}') and ok
    ids=set()
    for m in markets:
        if not all(m.get(k) for k in ('id','label','exchange','chart','specsUrl','tickSize','tickValue','unit')): ok=fail('incomplete market record: '+str(m.get('id'))) and ok
        if m.get('id') in ids: ok=fail('duplicate market id: '+str(m.get('id'))) and ok
        ids.add(m.get('id'))
        if not re.match(r'^https://',m.get('specsUrl',''),re.I): ok=fail('non-HTTPS exchange specs URL: '+str(m.get('id'))) and ok
        if float(m.get('tickSize') or 0)<=0 or float(m.get('tickValue') or 0)<=0: ok=fail('non-positive tick spec: '+str(m.get('id'))) and ok
        if m.get('microSpec') and (not m['microSpec'].get('symbol') or float(m['microSpec'].get('tickValue') or 0)<=0): ok=fail('invalid micro contract spec: '+str(m.get('id'))) and ok
        page=ROOT/'markets'/f"{m['id']}.html"
        if not page.is_file(): ok=fail('missing static contract page: '+str(page.name)) and ok
        else:
            p=Checker();p.feed(page.read_text(encoding='utf-8'));p.close()
            if not p.title or m['label'].split(' · ')[0].lower() not in p.title.lower(): ok=fail('contract SEO page title mismatch: '+page.name) and ok
    if markets:
        if 'NQ' not in markets[0]['label']: ok=fail('NQ should be first in the primary market universe') and ok

    play=json.loads((ROOT/'data'/'ict-playbook.json').read_text(encoding='utf-8'))
    if len(play.get('concepts',[]))!=21: ok=fail('expected 21 source-derived ICT concept entries') and ok
    if len(play.get('models',[]))!=8: ok=fail('expected 8 ICT entry models') and ok
    if len(play.get('sessions',[]))<10: ok=fail('session reference table incomplete') and ok
    if len(play.get('events',[]))<5: ok=fail('event snapshot incomplete') and ok

    academy=json.loads((ROOT/'data'/'ict-academy.json').read_text(encoding='utf-8'))
    lessons=academy.get('concepts',[])
    if len(lessons)<50: ok=fail(f'expected at least 50 ICT learning pages; found {len(lessons)}') and ok
    lesson_ids=[c.get('id') for c in lessons]
    if len(lesson_ids)!=len(set(lesson_ids)): ok=fail('duplicate ICT lesson IDs') and ok
    for c in lessons:
        if not all(c.get(k) for k in ('id','name','category','level','definition','howToUse','commonMistakes','evidence','videoSearch')): ok=fail('incomplete academy lesson: '+str(c.get('id'))) and ok
        if not re.match(r'^https://www\.youtube\.com/',c.get('videoSearch',''),re.I): ok=fail('invalid YouTube lesson search URL: '+str(c.get('id'))) and ok
        for ref in c.get('referenceLinks',[]):
            if not ref.get('name') or not re.match(r'^https://',ref.get('url',''),re.I): ok=fail('invalid academy source reference: '+str(c.get('id'))) and ok
        page=ROOT/'academy'/f"{c.get('id')}.html"
        if not page.is_file(): ok=fail('missing ICT lesson SEO page: '+page.name) and ok
        else:
            lp=Checker();lp.feed(page.read_text(encoding='utf-8'));lp.close()
            if not lp.title or c['name'].lower() not in lp.title.lower(): ok=fail('ICT lesson page title mismatch: '+page.name) and ok
    required_supplemental={'cisd','mmxm','turtle-soup','propulsion-block','breakaway-gap','opening-range-gap','event-horizon','reclaimed-order-block','suspension-block','vacuum-block','ny-lunch-reversal','market-maker-buy-model','market-maker-sell-model'}
    missing_supplemental=required_supplemental-set(lesson_ids)
    if missing_supplemental: ok=fail('missing supplemental ICT lessons: '+', '.join(sorted(missing_supplemental))) and ok
    if not any('SUPPLEMENTAL' in str(c.get('evidence','')) for c in lessons): ok=fail('supplemental lesson provenance labels are missing') and ok
    if 'globalSearch' not in idset: ok=fail('universal search is missing') and ok
    for t in academy.get('tracks',[]):
        for name in t.get('sequence',[]):
            if name not in {c.get('name') for c in lessons}: ok=fail('learning track references unknown lesson: '+name) and ok

    sources=json.loads((ROOT/'data'/'source-directory.json').read_text(encoding='utf-8'))
    source_rows=sources.get('sources',[])
    if sources.get('count')!=len(source_rows): ok=fail('source-directory count mismatch') and ok
    if len(source_rows)<30 or len(source_rows)>60: ok=fail('futures source directory should contain 30–60 curated destinations') and ok
    for s in source_rows:
        if not s.get('name') or not s.get('category') or not re.match(r'^https://',s.get('url',''),re.I): ok=fail('invalid source row: '+str(s.get('name'))) and ok
    resources=json.loads((ROOT/'resources.json').read_text(encoding='utf-8'))
    if resources.get('count')!=len(resources.get('resources',[])): ok=fail('resources.json count mismatch') and ok
    if len(resources.get('resources',[]))!=len(source_rows): ok=fail('resources.json does not mirror curated source directory') and ok
    unrelated={'India Markets','India Market Access & Official Data','Investigative Leaks & OSINT','Private Markets, Real Assets & Specialty Finance','Pump/Dump Risk & Token Safety','Crypto & On-chain'}
    found=unrelated.intersection(resources.get('categories',[]))
    if found: ok=fail('unrelated categories remain: '+', '.join(sorted(found))) and ok
    normalized=[r.get('url','').rstrip('/').lower() for r in source_rows]
    if len(normalized)!=len(set(normalized)): ok=fail('duplicate source URLs remain') and ok

    social=json.loads((ROOT/'data'/'social-analysis-methods.json').read_text(encoding='utf-8'))
    platform_ids={x.get('id') for x in social.get('platforms',[])}
    for needed in ('tradingview','x','linkedin','youtube','reddit'):
        if needed not in platform_ids: ok=fail('missing public research platform '+needed) and ok
    snapshot=json.loads((ROOT/'data'/'news-snapshot.json').read_text(encoding='utf-8'))
    if snapshot.get('schemaVersion')!=1 or not isinstance(snapshot.get('articles'),list): ok=fail('news snapshot schema invalid') and ok
    for a in snapshot.get('articles',[]):
        if not a.get('title') or not re.match(r'^https?://',a.get('url',''),re.I): ok=fail('invalid news snapshot article') and ok
    queries=json.loads((ROOT/'data'/'news-queries.json').read_text(encoding='utf-8'))
    if len(queries.get('queries',[]))<5: ok=fail('futures news query set too small') and ok

    required_files=['.nojekyll','manifest.webmanifest','icon.svg','sw.js','README.md','LICENSE','CONTRIBUTING.md','SECURITY.md','src-index.template.html','robots.txt','sitemap.xml','data/ict-academy.json','scripts/build_html.py','scripts/build_market_pages.py','scripts/build_academy_pages.py','scripts/fetch_news_snapshot.py','scripts/build_site.py','scripts/audit_links.py','.github/workflows/quality.yml','.github/workflows/pages.yml','.github/workflows/link-audit.yml']
    for f in required_files:
        if not (ROOT/f).exists(): ok=fail('missing package file '+f) and ok
    manifest=json.loads((ROOT/'PACKAGE-MANIFEST.json').read_text(encoding='utf-8'))
    if manifest.get('version')!='3.0.0': ok=fail('package manifest version must be 3.0.0') and ok
    for entry in manifest.get('files',[]):
        p=ROOT/entry['path']
        if not p.is_file(): ok=fail('manifest file missing: '+entry['path']) and ok; continue
        raw=p.read_bytes()
        if len(raw)!=entry.get('bytes'): ok=fail('manifest byte-count mismatch: '+entry['path']) and ok
        if hashlib.sha256(raw).hexdigest()!=entry.get('sha256'): ok=fail('manifest checksum mismatch: '+entry['path']) and ok
    for name in manifest.get('dynamicFiles',[]):
        if not (ROOT/name).exists(): ok=fail('manifest dynamic file missing: '+name) and ok
    node=shutil.which('node'); js_count=0
    if node:
        with tempfile.TemporaryDirectory(prefix='ict-futures-js-') as td:
            for i,(attrs,source) in enumerate(parser.scripts):
                typ=attrs.get('type','text/javascript').lower()
                if attrs.get('src') or not source.strip() or typ in ('application/ld+json','application/json','text/template'): continue
                path=Path(td)/f'inline-{i}.js';path.write_text(source,encoding='utf-8')
                result=subprocess.run([node,'--check',str(path)],capture_output=True,text=True);js_count+=1
                if result.returncode: ok=fail(f'inline JavaScript syntax error in block {i}: '+(result.stderr or result.stdout).strip()[:500]) and ok
            sw=subprocess.run([node,'--check',str(ROOT/'sw.js')],capture_output=True,text=True)
            if sw.returncode: ok=fail('service worker JavaScript syntax error: '+sw.stderr.strip()[:500]) and ok
    else: print('WARN: Node not found; skipped JavaScript syntax checks.')
    print(f'HTML IDs: {len(parser.ids)} (unique: {len(idset)})')
    print(f'Anchor links: {len(parser.links)}; broken internal anchors: {len(broken_hashes)}')
    print(f'Futures: {len(markets)} families (T1 {counts.get("T1")}, T2 {counts.get("T2")}, T3 {counts.get("T3")})')
    print(f'ICT playbook concepts: {len(play.get("concepts",[]))}; academy lessons: {len(lessons)}; entry models: {len(play.get("models",[]))}; sessions: {len(play.get("sessions",[]))}')
    print(f'Curated sources: {len(source_rows)}; contract SEO pages: {len(list((ROOT/"markets").glob("*.html")))}; academy SEO pages: {len(list((ROOT/"academy").glob("*.html")))}; inline JS blocks checked: {js_count}')
    print(f"Snapshot status: {snapshot.get('status')}; articles in tracked snapshot: {len(snapshot.get('articles', []))}")
    print('PASS' if ok else 'FAILED')
    return 0 if ok else 1
if __name__=='__main__': sys.exit(main())
