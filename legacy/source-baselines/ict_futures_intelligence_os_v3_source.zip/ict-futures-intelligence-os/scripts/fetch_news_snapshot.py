#!/usr/bin/env python3
"""Fetch a best-effort, public GDELT news snapshot for the published static site.

No API keys or credentials are required. Provider failures never invent headlines
and do not erase a previously saved snapshot. The site-output file can carry the
latest check status without forcing a repository commit every time the same
articles are returned.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlparse
from urllib.request import Request, urlopen

API_URL = "https://api.gdeltproject.org/api/v2/doc/doc"
ROOT = Path(__file__).resolve().parents[1]
QUERY_FILE = ROOT / "data" / "news-queries.json"
try:
    _query_payload = json.loads(QUERY_FILE.read_text(encoding="utf-8"))
    QUERIES = [{"label": row["label"], "query": row["query"]} for row in _query_payload.get("queries", [])]
except (OSError, ValueError, KeyError, TypeError):
    QUERIES = []
if not QUERIES:
    raise RuntimeError("No futures news queries found in data/news-queries.json")


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _date_rank(value: str) -> float:
    if not value:
        return 0.0
    try:
        if re.fullmatch(r"\d{8}T\d{6}Z", value):
            dt = datetime.strptime(value, "%Y%m%dT%H%M%SZ").replace(tzinfo=timezone.utc)
        else:
            dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return dt.timestamp()
    except (ValueError, TypeError):
        return 0.0


def normalize_article(article: dict, topic: str = "General") -> dict | None:
    """Keep only usable public article records and normalize fields for the UI."""
    if not isinstance(article, dict):
        return None
    url = str(article.get("url") or "").strip()
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return None
    title = re.sub(r"\s+", " ", str(article.get("title") or "")).strip()
    if not title:
        return None
    domain = str(article.get("domain") or parsed.hostname or "").lower().strip()
    try:
        tone = float(article["tone"]) if article.get("tone") not in (None, "") else None
    except (ValueError, TypeError):
        tone = None
    result = {
        "title": title[:800],
        "url": url,
        "seendate": str(article.get("seendate") or article.get("published_at") or ""),
        "domain": domain[:255],
        "language": str(article.get("language") or "")[:30],
        "sourceCountry": str(article.get("sourceCountry") or article.get("sourcecountry") or "")[:80],
        "sourceCommonName": str(article.get("sourceCommonName") or "")[:255],
        "topic": topic[:100],
    }
    if tone is not None:
        result["tone"] = tone
    return result


def merge_articles(items: list[dict], max_articles: int = 80) -> list[dict]:
    """Deduplicate by normalized URL, retaining the first (highest-ranked) item."""
    seen: set[str] = set()
    normalized: list[dict] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        key = str(item.get("url") or "").strip().rstrip("/").lower()
        if not key or key in seen:
            continue
        parsed = urlparse(key)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            continue
        seen.add(key)
        normalized.append(item)
    normalized.sort(key=lambda x: _date_rank(str(x.get("seendate") or x.get("published_at") or "")), reverse=True)
    return normalized[:max(0, max_articles)]


def request_query(spec: dict, timespan: str, max_records: int, timeout: float) -> tuple[dict, list[dict], str | None]:
    params = {
        "query": spec["query"],
        "mode": "ArtList",
        "format": "json",
        "maxrecords": str(max_records),
        "sort": "DateDesc",
        "timespan": timespan,
    }
    url = API_URL + "?" + urlencode(params)
    last_error = "unknown provider error"
    for attempt in range(2):
        try:
            req = Request(url, headers={"Accept": "application/json", "User-Agent": "FinanceIntelligenceOS/2.2 (public research snapshot; no tracking)"})
            with urlopen(req, timeout=timeout) as response:
                raw = response.read(4_000_000)
            payload = json.loads(raw.decode("utf-8", errors="replace"))
            if not isinstance(payload, dict) or not isinstance(payload.get("articles", []), list):
                raise ValueError("Unexpected GDELT response schema")
            articles = [x for item in payload.get("articles", []) if (x := normalize_article(item, spec["label"]))]
            return spec, articles, None
        except (HTTPError, URLError, TimeoutError, ValueError, json.JSONDecodeError, OSError) as exc:
            last_error = f"{type(exc).__name__}: {str(exc)[:180]}"
            if attempt == 0:
                time.sleep(1)
    return spec, [], last_error


def load_snapshot(path: Path) -> dict:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict) and isinstance(data.get("articles"), list):
            return data
    except (OSError, json.JSONDecodeError):
        pass
    return {"schemaVersion": 1, "provider": "GDELT DOC API", "status": "not-yet-fetched", "generatedAt": None, "lastCheckedAt": None, "window": "24h", "articles": []}


def article_signature(articles: list[dict]) -> tuple:
    return tuple((str(a.get("url", "")).rstrip("/").lower(), str(a.get("title", "")), str(a.get("seendate", ""))) for a in articles)


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def fetch_snapshot(previous: dict, timespan: str, max_records: int, timeout: float, workers: int = 4) -> tuple[dict, bool]:
    checked_at = utc_now()
    outcomes: list[tuple[dict, list[dict], str | None]] = []
    with ThreadPoolExecutor(max_workers=max(1, min(workers, len(QUERIES)))) as pool:
        futures = [pool.submit(request_query, spec, timespan, max_records, timeout) for spec in QUERIES]
        for future in as_completed(futures):
            try:
                outcomes.append(future.result())
            except Exception as exc:  # defensive: one query must not crash the entire snapshot
                outcomes.append(({"label": "Unknown query", "query": ""}, [], f"{type(exc).__name__}: {str(exc)[:180]}"))
    outcomes.sort(key=lambda x: next((i for i, q in enumerate(QUERIES) if q["label"] == x[0].get("label")), 999))
    successful = sum(1 for _, _, err in outcomes if err is None)
    candidate = merge_articles([a for _, articles, err in outcomes if err is None for a in articles], max_articles=90)
    old_articles = previous.get("articles", []) if isinstance(previous.get("articles"), list) else []
    old_articles = merge_articles(old_articles, max_articles=90)
    valid_results = successful > 0 and bool(candidate)
    if valid_results:
        articles = candidate
        changed = article_signature(articles) != article_signature(old_articles)
        status = "fresh" if successful == len(QUERIES) else "partial"
        generated_at = checked_at if changed or not previous.get("generatedAt") else previous.get("generatedAt")
        notes = ["Scheduled GDELT snapshot; indexing time may differ from original publication time.", "Aggregated futures headlines are leads, not verified facts or calibrated trading signals."]
    elif old_articles:
        articles = old_articles
        changed = False
        status = "stale"
        generated_at = previous.get("generatedAt")
        notes = ["Fresh results were unavailable or empty; prior saved articles are retained.", "These are stale/last-known results, not a live market feed."]
    else:
        articles = []
        changed = False
        status = "partial" if successful else "unavailable"
        generated_at = previous.get("generatedAt")
        notes = ["No articles could be confirmed in this run.", "Use on-demand provider links; a failed provider request does not indicate no news exists."]
    query_rows = []
    for spec, records, error in outcomes:
        query_rows.append({"label": spec.get("label", "Unknown query"), "success": error is None, "articleCount": len(records), **({"error": error} if error else {})})
    site_payload = {
        "schemaVersion": 1,
        "provider": "GDELT DOC API",
        "status": status,
        "generatedAt": generated_at,
        "lastCheckedAt": checked_at,
        "window": timespan,
        "queryCount": len(QUERIES),
        "successfulQueries": successful,
        "articles": articles,
        "queries": query_rows,
        "notes": notes,
    }
    persistent_payload = dict(site_payload)
    # Keep the committed snapshot's last-check timestamp stable when article content
    # has not changed; GitHub does not need a bot commit every scheduled run.
    persistent_payload["lastCheckedAt"] = checked_at if changed else previous.get("lastCheckedAt")
    persistent_payload["status"] = status if changed or not previous.get("articles") else previous.get("status", status)
    return {"persistent": persistent_payload, "site": site_payload, "changed": changed, "successful": successful, "queryCount": len(QUERIES), "articleCount": len(articles)}, changed


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="data/news-snapshot.json", help="Persisted repo snapshot path")
    parser.add_argument("--site-output", default="", help="Optional deploy artifact snapshot path with current lastCheckedAt")
    parser.add_argument("--timespan", default="24h", choices=["24h", "48h", "72h", "7d"], help="Provider search window")
    parser.add_argument("--max-records", type=int, default=15, help="Max articles per query (1-50)")
    parser.add_argument("--timeout", type=float, default=12, help="Per-query timeout seconds")
    args = parser.parse_args()
    if not 1 <= args.max_records <= 50 or args.timeout <= 0:
        parser.error("--max-records must be 1-50 and --timeout must be positive")
    output = Path(args.output)
    previous = load_snapshot(output)
    result, changed = fetch_snapshot(previous, args.timespan, args.max_records, args.timeout)
    # Persist content changes only; no empty/failed fetch may erase last-known articles.
    if changed or not output.exists():
        write_json(output, result["persistent"])
    if args.site_output:
        write_json(Path(args.site_output), result["site"])
    print(f"Snapshot status: {result['site']['status']}; successful queries: {result['successful']}/{result['queryCount']}; articles: {result['articleCount']}; content changed: {changed}")
    for row in result["site"].get("queries", []):
        if not row.get("success"):
            print(f"WARN: {row.get('label')}: {row.get('error','provider error')}", file=sys.stderr)
    # Provider outages are not a reason to block static-site deployment.
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
