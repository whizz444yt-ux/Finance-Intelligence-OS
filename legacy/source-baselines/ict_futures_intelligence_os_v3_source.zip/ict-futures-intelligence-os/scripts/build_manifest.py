#!/usr/bin/env python3
"""Regenerate PACKAGE-MANIFEST.json checksums for tracked project files."""
from pathlib import Path
from datetime import date
import hashlib, json
ROOT = Path(__file__).resolve().parents[1]
DYNAMIC = {'data/news-snapshot.json'}
EXCLUDED_PARTS = {'.git', '__pycache__', '.pytest_cache', 'dist', 'site-dist'}

def main():
    old = {}
    try: old = json.loads((ROOT/'PACKAGE-MANIFEST.json').read_text(encoding='utf-8'))
    except Exception: pass
    version = '3.0.0'
    files = []
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or path.name == 'PACKAGE-MANIFEST.json': continue
        rel = path.relative_to(ROOT).as_posix()
        if rel in DYNAMIC or any(part in EXCLUDED_PARTS for part in path.relative_to(ROOT).parts): continue
        data = path.read_bytes()
        files.append({'path': rel, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    resources = json.loads((ROOT/'resources.json').read_text(encoding='utf-8'))
    markets = json.loads((ROOT/'data/market-universe.json').read_text(encoding='utf-8'))
    payload = {
        'name': 'ICT Futures Intelligence OS — Futures Research Edition',
        'version': version,
        'generatedAt': date.today().isoformat(),
        'resourceCount': len(resources.get('resources', [])),
        'contractFamilyCount': len(markets.get('markets', [])),
        'resourceCategoryCount': len(resources.get('categories', [])),
        'marketPresetCount': len(markets.get('markets', [])),
        'dynamicFiles': sorted(DYNAMIC),
        'files': files,
    }
    (ROOT/'PACKAGE-MANIFEST.json').write_text(json.dumps(payload, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
    print(f"Manifest updated: {len(files)} checksummed files; {payload['resourceCount']} curated sources; {payload['contractFamilyCount']} futures families.")
if __name__=='__main__': main()
