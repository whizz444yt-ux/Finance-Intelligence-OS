#!/usr/bin/env python3
"""Generate an external link-health report; network issues are reported, not hidden."""
from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor, as_completed
from html.parser import HTMLParser
from pathlib import Path
import argparse, csv, json, socket, sys
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

ROOT=Path(__file__).resolve().parents[1]
class LinkParser(HTMLParser):
    def __init__(self): super().__init__(); self.links=[]
    def handle_starttag(self, tag, attrs):
        if tag=='a':
            d=dict(attrs); h=d.get('href','')
            if h.startswith(('https://','http://')): self.links.append(h)

def get_urls():
    data=json.loads((ROOT/'resources.json').read_text(encoding='utf-8'))
    urls=[r.get('url','') for r in data.get('resources',[]) if r.get('url')]
    parser=LinkParser(); parser.feed((ROOT/'index.html').read_text(encoding='utf-8'))
    urls.extend(parser.links)
    uniq=[]; seen=set()
    for url in urls:
        normalized=url.rstrip('/').lower()
        if normalized and normalized not in seen:
            seen.add(normalized); uniq.append(url)
    return uniq

def check_one(url, timeout):
    result={'url':url,'http_status':'','final_url':'','classification':'unknown','detail':''}
    parsed=urlparse(url)
    if parsed.scheme not in {'http','https'} or not parsed.netloc:
        result.update(classification='invalid_url',detail='Invalid HTTP(S) URL'); return result
    def make_request(method):
        req=Request(url,headers={'User-Agent':'Finance-Intelligence-OS-Link-Audit/2.2 (+https://github.com/)','Accept':'text/html,application/json,*/*'},method=method)
        if method=='GET': req.add_header('Range','bytes=0-1023')
        return urlopen(req,timeout=timeout)
    try:
        try:
            response=make_request('HEAD')
        except HTTPError as exc:
            if exc.code in (400,403,405,406,409,416,429,501):
                try: response=make_request('GET')
                except HTTPError as get_exc:
                    result.update(http_status=get_exc.code,final_url=get_exc.geturl(),classification=_classify_status(get_exc.code),detail='GET after HEAD failed'); return result
            else:
                result.update(http_status=exc.code,final_url=exc.geturl(),classification=_classify_status(exc.code),detail='HEAD request returned HTTP error'); return result
        with response:
            code=response.status; final=response.geturl()
        result.update(http_status=code,final_url=final,classification=_classify_status(code),detail='Redirected' if final.rstrip('/')!=url.rstrip('/') else '')
    except HTTPError as exc:
        result.update(http_status=exc.code,final_url=exc.geturl(),classification=_classify_status(exc.code),detail=str(exc.reason)[:180])
    except (URLError,TimeoutError,socket.timeout,OSError) as exc:
        result.update(classification='network_error_or_blocked',detail=f'{type(exc).__name__}: {str(exc)[:180]}')
    except Exception as exc:
        result.update(classification='checker_error',detail=f'{type(exc).__name__}: {str(exc)[:180]}')
    return result

def _classify_status(code):
    if 200<=code<300: return 'ok'
    if 300<=code<400: return 'redirect'
    if code in (401,403,407): return 'blocked_or_auth_required'
    if code==404 or code==410: return 'likely_broken'
    if code==429: return 'rate_limited'
    if 500<=code<600: return 'server_error'
    return 'http_error'

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',default='link-audit.csv',help='CSV report path')
    ap.add_argument('--limit',type=int,default=0,help='Optional maximum URLs; 0 checks all')
    ap.add_argument('--timeout',type=float,default=8,help='Per-request timeout seconds')
    ap.add_argument('--workers',type=int,default=12,help='Concurrent checks (max 20)')
    args=ap.parse_args()
    if args.timeout<=0 or args.workers<1 or args.workers>20 or args.limit<0: ap.error('Invalid timeout, workers or limit')
    urls=get_urls()
    if args.limit: urls=urls[:args.limit]
    rows=[]
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures=[pool.submit(check_one,url,args.timeout) for url in urls]
        for fut in as_completed(futures): rows.append(fut.result())
    order={u:i for i,u in enumerate(urls)}; rows.sort(key=lambda r:order.get(r['url'],999999))
    out=Path(args.output); out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=['url','http_status','final_url','classification','detail']); writer.writeheader(); writer.writerows(rows)
    counts={}
    for r in rows: counts[r['classification']]=counts.get(r['classification'],0)+1
    print(f'Checked {len(rows)} unique URLs. Report: {out}')
    for key,count in sorted(counts.items()): print(f'{key}: {count}')
    print('Note: anti-bot responses, network blocks and rate limits are not proof a source is dead.')
    # This is an audit report, not a build gate: transient provider failures are common.
    return 0
if __name__=='__main__': raise SystemExit(main())
