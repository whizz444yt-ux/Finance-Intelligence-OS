# Finance Intelligence OS — Global Market Cockpit

A static, open-source research dashboard that brings global market discovery, news-search workflows, source links, optional live headline aggregation, market presets, a watchlist and a local research journal into one interface.

> **Scope:** this is a research cockpit, not a licensed live-data terminal, broker, execution platform, or forecast engine. It cannot guarantee that every worldwide market feed is complete, real-time, accurate, or available 24/7.

## What is included

- `index.html` — main single-page application. It can be opened directly in a modern browser; core directory/search features do not require a build step.
- `manifest.webmanifest`, `icon.svg`, `sw.js` — progressive-web-app metadata and best-effort offline shell for HTTPS hosting.
- `resources.json` — `560` deduplicated curated resource entries in a machine-readable format.
- `data/market-universe.json` — `73` market/instrument presets with symbols, research queries, common drivers and primary reference URLs.
- `scripts/validate.py` — local integrity checks for HTML structure, IDs, resource URLs and package files.

## Features

1. Cross-asset instrument navigator for FX, equity indices, equities, bonds/rates, metals, energy, agriculture, crypto, volatility and specialist markets.
2. One-tap links to charts, global headlines, Google News search/RSS, X search, Google Trends, Reddit, video search, event calendars and relevant official sources.
3. Optional **user-triggered** GDELT document API query. It is a best-effort connector; browser CORS, network filters, throttling, outages or provider changes can prevent a response. Cached results are labelled as cached, not live.
4. Optional embedded TradingView chart, loaded only after the user clicks the chart button. It depends on an external provider and a recognized symbol mapping.
5. Watchlist and research notes saved locally in the current browser via `localStorage`.
6. JSON workspace backup/import and CSV journal export.
7. Theme toggle, IANA time-zone clocks, scenario-impact notes and local diagnostics.
8. Searchable resource directory with category and India-status filters, resource CSV export, plus a separate JSON resource index.

## Run locally

You can open `index.html` in a modern browser. The static research directory and local journal work without a backend. Some browser security features (notably service workers/PWA install) require HTTPS or `localhost`.

For local HTTP testing:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000/`.

## Deploy on GitHub Pages

1. Create a GitHub repository and upload the contents of this package to the repository root.
2. Open **Settings → Pages**.
3. Choose deployment from the `main` branch and `/ (root)` (or use the deployment option your repository supports).
4. Wait for GitHub Pages to publish the HTTPS site, then open the published URL.
5. Confirm the app loads; in browser developer tools, check service-worker registration and console warnings. The offline shell becomes available after a successful first visit, subject to the browser's storage policy.

This package is compatible with a repository subpath (for example, `https://USERNAME.github.io/REPOSITORY/`) because its assets and service-worker registration use relative paths.

## Data freshness and accuracy

- The dashboard does not fetch every listed provider automatically. Most sources are **one-click links** that open the provider's website or search page.
- The GDELT connector performs a real fetch only after the user clicks **Fetch recent headlines**. A successful response is not proof that an article is accurate, original, or complete.
- Provider timestamps can represent publication, indexing, event-seen or retrieval time. Keep those meanings distinct.
- Social accounts, on-chain alerts, unusual volume, option flow and search-interest spikes are leads, not proof of future price direction.
- Forecasts must be stored with issuer, time, horizon, target/range, assumptions, source and subsequent outcome if you later add forecast evaluation.
- The `indiaStatus` values in `resources.json` describe resource/access research metadata, not universal legal clearance for all products on a provider.

## Live market data and provider integrations

A GitHub Pages static site cannot securely hold secret API keys or guarantee persistent 24/7 data ingestion. For production-grade real-time news, quotes, economic releases and alerts:

1. Put API keys in backend environment secrets (for example, a serverless function or private server), never in public frontend JavaScript or a public GitHub repository.
2. Build a provider adapter per feed, normalize timestamps to UTC while retaining provider timezone and event time, deduplicate articles, and store provenance.
3. Track `published_at`, `event_at`, `retrieved_at`, `provider`, `instrument`, `venue`, `latency_class`, `license`, `correction_status` and failure state.
4. Respect provider rate limits, commercial use and exchange redistribution rules. A public API does not automatically grant redistribution rights for every field.
5. Add timeouts, retry/backoff, cache bounds, circuit breakers, health checks, observability and provider-specific fallbacks.

Useful official developer references include [SEC EDGAR APIs](https://www.sec.gov/search-filings/edgar-application-programming-interfaces), [FRED API](https://fred.stlouisfed.org/docs/api/fred/), [GDELT](https://www.gdeltproject.org/), [OpenBB documentation](https://docs.openbb.co/), and [TradingView Lightweight Charts](https://github.com/tradingview/lightweight-charts). The open-source Lightweight Charts library is Apache 2.0 licensed and has its own attribution requirements; this project only links to it and does not bundle the library source.

## Privacy

- The watchlist, theme, cached GDELT results and research journal are stored in the visitor's local browser profile.
- They are not uploaded by this app. A user can export and import a JSON backup.
- Do not commit personal backups, API tokens, credentials or private research notes into a public repository.
- External provider links, chart widgets and API requests send normal requests to the relevant third parties when used.

## License

The application code in this repository is offered under the MIT License. Third-party websites, APIs, datasets, logos, financial data and linked source content remain subject to their own terms, licenses and attribution requirements. MIT licensing of the app does not grant rights to redistribute third-party market data.

## Contributing

See `CONTRIBUTING.md` and `SECURITY.md`. Before adding a source, include a direct URL, what the source actually provides, whether access is public/freemium/paid, data delay/frequency if known, and any jurisdiction or licensing caveat. Avoid claims such as “guaranteed pump”, “sure-shot signal” or “all global news” unless the data coverage genuinely supports it.
