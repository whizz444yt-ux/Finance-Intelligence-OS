# Changelog

## 2.0.0 — 2026-10-26
- Added user-triggered live GDELT headline reader with timeout, safe URL handling, cache labels and fallback links.
- Added embedded chart loader that loads the external TradingView widget only after user action.
- Added browser-local watchlist and research journal with JSON import/export and CSV export.
- Added theme persistence, saved market/horizon, local diagnostics, PWA metadata and best-effort offline shell.
- Added machine-readable resource and market-universe JSON files.
- Clarified that external data availability, freshness and legal eligibility are provider/jurisdiction dependent.
