#!/usr/bin/env python3
"""Offline structural checks for Finance Intelligence OS."""
from pathlib import Path
from html.parser import HTMLParser
import json, re, sys
ROOT = Path(__file__).resolve().parents[1]
class Checker(HTMLParser):
    def __init__(self): super().__init__(); self.ids=[]; self.links=[]; self.title=False; self.in_title=False
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if 'id' in a:self.ids.append(a['id'])
        if tag=='a' and a.get('href'):self.links.append((a['href'],a.get('target'),a.get('rel','')))
        if tag=='title':self.in_title=True
    def handle_endtag(self,tag):
        if tag=='title':self.in_title=False
    def handle_data(self,data):
        if self.in_title and 'Finance Intelligence OS' in data:self.title=True

def fail(msg): print('FAIL:',msg); return False
def main():
    ok=True
    html_path=ROOT/'index.html'
    html=html_path.read_text(encoding='utf-8')
    parser=Checker(); parser.feed(html)
    if not parser.title: ok=fail('missing/incorrect title') and ok
    duplicates=sorted({x for x in parser.ids if parser.ids.count(x)>1})
    if duplicates: ok=fail('duplicate ids: '+', '.join(duplicates)) and ok
    required=['market-cockpit','instrument-navigator','x-news-desk','social-analysis-lab','salViewForm','salMathCalculate','impact-lab','live-news-hub','personal-workspace','directory','runLocalDiagnostics']
    missing=[x for x in required if x not in parser.ids]
    if missing: ok=fail('missing expected UI ids: '+', '.join(missing)) and ok
    data=json.loads((ROOT/'resources.json').read_text(encoding='utf-8'))
    records=data.get('resources',[])
    if data.get('count')!=len(records): ok=fail('resources.json count does not match resource length') and ok
    normalized=[]
    for r in records:
        if not r.get('name') or not r.get('category'): ok=fail('resource missing name/category') and ok
        if not re.match(r'^https?://',r.get('url',''),re.I): ok=fail('non-http(s) resource URL: '+str(r.get('url'))) and ok
        normalized.append(r.get('url','').rstrip('/').lower())
    if len(normalized)!=len(set(normalized)): ok=fail('duplicate normalized resource URLs remain') and ok
    social=json.loads((ROOT/'data'/'social-analysis-methods.json').read_text(encoding='utf-8'))
    if not social.get('methods') or not social.get('platforms'): ok=fail('social-analysis-methods.json missing methods/platforms') and ok
    markets=json.loads((ROOT/'data'/'market-universe.json').read_text(encoding='utf-8'))
    if markets.get('count')!=len(markets.get('markets',[])): ok=fail('market-universe count mismatch') and ok
    for f in ['manifest.webmanifest','icon.svg','sw.js','README.md','LICENSE','CONTRIBUTING.md','SECURITY.md']:
        if not (ROOT/f).exists():ok=fail('missing package file '+f) and ok
    # External links that open a new tab must use rel=noopener or noreferrer.
    bad=[h for h,t,r in parser.links if t=='_blank' and ('noopener' not in r and 'noreferrer' not in r)]
    if bad: ok=fail(f'{len(bad)} external links use target=_blank without noopener/noreferrer') and ok
    print(f"HTML ids: {len(parser.ids)} (unique: {len(set(parser.ids))})")
    print(f"Resource records: {len(records)} across {len(data.get('categories',[]))} categories")
    print(f"Market presets: {len(markets.get('markets',[]))}")
    print(f"Anchor links checked: {len(parser.links)}")
    print('PASS' if ok else 'FAILED')
    return 0 if ok else 1
if __name__=='__main__':sys.exit(main())
