# Changelog

## 2.1.0 — 2026-10-26
- Added Social Chart Analysis Lab for pair-specific multi-platform searching by methodology and time horizon.
- Added source-profile cards for news, official data, chart analysis, options and on-chain commentary. Profiles are discovery links, not endorsements.
- Added local source-linked viewpoint ledger with confidence, levels, invalidation, manual outcome review, hit-rate summary and Brier score.
- Added reward/risk geometry calculator.
- Added new resources for TradingView Ideas, X search, open-source social listening and quantitative research.
- Explicitly labelled astrology/cycle analysis as speculative and separated it from empirical methods.
- Preserved existing news, chart, watchlist, journal, data-quality and country-status features.

## 2.0.0
- Introduced global market cockpit, multi-asset presets, selected live GDELT news reader, chart embed, local journal and GitHub Pages packaging.
