# Security Policy

## Reporting
Report a vulnerability privately to the repository maintainer rather than publishing an exploit or exposing user data in a public issue.

## Data and secrets
This is a static client-side app. Do not place API keys, credentials, personal research notes, exported workspace backups or private endpoints in public source files. Production feed integrations should use a server-side proxy or serverless function with secrets stored in the hosting provider's secret manager.

## Threat model notes
- RSS/news article metadata is untrusted input. Render it as text and only allow `https:`/`http:` source URLs.
- External websites can change, become unavailable, impose paywalls or change access terms.
- Cached workspace data lives in local browser storage and can be cleared by the user or browser.
- The app does not execute trades or connect to a broker account.
