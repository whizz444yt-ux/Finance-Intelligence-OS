# Finance Intelligence OS — Global Research Edition

A static, open-source research dashboard for global market discovery, multi-platform news searches, chart viewpoints, method comparison, manual forecast scoring, risk/reward maths, a scheduled public-news snapshot, optional on-demand GDELT headlines, market presets, a watchlist and a local research journal.

> **Scope:** this is a research cockpit, not a licensed live-data terminal, broker, execution platform, or forecast engine. It cannot guarantee that every worldwide market feed is complete, real-time, accurate, or available 24/7.

## What is included

- `index.html` — main single-page application. It can be opened directly in a modern browser; core directory/search features do not require a build step.
- `manifest.webmanifest`, `icon.svg`, `sw.js` — progressive-web-app metadata and best-effort offline shell for HTTPS hosting.
- `resources.json` — `585` deduplicated curated resource entries in a machine-readable format.
- `data/market-universe.json` — `73` market/instrument presets with symbols, research queries, common drivers and primary reference URLs.
- `data/news-snapshot.json` — latest published GDELT search snapshot; updated best-effort by GitHub Actions. Its article content is persisted only when the result set changes.
- `scripts/fetch_news_snapshot.py` — public, no-key GDELT snapshot collector with timeouts, query-level status, deduplication and stale-data retention.
- `scripts/build_site.py` — builds an allow-listed static payload for Pages.
- `scripts/audit_links.py` — optional external-link health report; protected sites can return 403/429 without being dead.
- `scripts/validate.py` and `tests/` — offline integrity checks, inline JavaScript syntax checks (when Node is available) and network-mocked news collector tests.
- `.github/workflows/quality.yml` — automated structural and unit tests.
- `.github/workflows/pages.yml` — GitHub Pages deployment on pushes plus a best-effort hourly public-news snapshot refresh at minute 17.
- `.github/workflows/link-audit.yml` — weekly/manual external link health report artifact.

## Features

- Social Chart Analysis Lab: search the same asset across X, TradingView Ideas, YouTube, Google News, Reddit, Stocktwits and Bluesky by method and horizon.
- Public analyst-source directory with profile and selected-market search links; profiles are discovery starting points, not endorsements.
- Local viewpoint ledger for source URL, method, thesis, levels, horizon, confidence, manual outcome and a simple hit-rate/Brier-score summary.
- Methodology comparison across technical/price action, ICT/SMC, Wyckoff, Elliott Wave, quantitative/statistical, order flow, options, macro, on-chain, sentiment, Gann/cycles, astrology (explicitly speculative) and AI/ML.
- Mathematical setup sanity-check for stop distance, target distance, reward:risk and theoretical unit count for an entered risk budget.

1. Cross-asset instrument navigator for FX, equity indices, equities, bonds/rates, metals, energy, agriculture, crypto, volatility and specialist markets.
2. One-tap links to charts, global headlines, Google News search/RSS, X search, Google Trends, Reddit, video search, event calendars and relevant official sources.
3. Optional **user-triggered** GDELT document API query. It is a best-effort connector; browser CORS, network filters, throttling, outages or provider changes can prevent a response. Cached results are labelled as cached, not live.
4. Optional embedded TradingView chart, loaded only after the user clicks the chart button. It depends on an external provider and a recognized symbol mapping.
5. Watchlist and research notes saved locally in the current browser via `localStorage`.
6. JSON workspace backup/import and CSV journal export.
7. Theme toggle, IANA time-zone clocks, scenario-impact notes and local diagnostics.
8. Searchable resource directory with category and India-status filters, resource CSV export, plus a separate JSON resource index.

## Run locally

You can open `index.html` in a modern browser. The static research directory and local journal work without a backend. Some browser security features (notably service workers/PWA install) require HTTPS or `localhost`.

For local HTTP testing:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000/`.

## Deploy on GitHub Pages

1. Create a public GitHub repository and upload the contents of this package, including the `.github/` directory, to its root. Keep `main` as the default branch unless you also update the workflow branch filters.
2. Open **Settings → Pages** and choose **GitHub Actions** as the publishing source. Do not choose the legacy branch-root source when using `pages.yml`.
3. Push/commit the files. The `pages.yml` workflow builds an allow-listed `dist/` payload, attempts to refresh public GDELT headlines, validates the package, and deploys the site.
4. Open the `Actions` tab and verify both **Quality checks** and **Deploy Finance Intelligence OS to GitHub Pages**. The Pages job reports the published URL.
5. Test the HTTPS URL in desktop and mobile browsers. Check news fetch status, chart-provider load, local storage, export/import and the service-worker status.

The workflow needs `contents: write`, `pages: write` and `id-token: write` permissions; if organization policies or branch protection reject a bot commit, the site deployment still uses the current fetched snapshot artifact, but the snapshot may not be persisted between runs.

This package is compatible with a repository subpath (for example, `https://USERNAME.github.io/REPOSITORY/`) because its assets and service-worker registration use relative paths.

## Data freshness and accuracy

- The dashboard does not ingest every listed provider automatically. Most sources are **one-click links** that open the provider's website or search page. Social chart searches are not a universal X/Reddit/YouTube ingestion API.
- The website includes a scheduled GDELT snapshot refreshed by GitHub Actions on a best-effort hourly schedule and a manual on-demand fetch button. Scheduled jobs can be delayed or skipped; feed coverage is not comprehensive.
- A successful GDELT response is not proof that an article is accurate, original, or complete. Headlines can be syndicated or indexed late.
- Provider timestamps can represent publication, indexing, event-seen or retrieval time. Keep those meanings distinct.
- Social accounts, on-chain alerts, unusual volume, option flow and search-interest spikes are leads, not proof of future price direction.
- Forecasts must be stored with issuer, time, horizon, target/range, assumptions, source and subsequent outcome if you later add forecast evaluation.
- The `indiaStatus` values in `resources.json` describe resource/access research metadata, not universal legal clearance for all products on a provider.

## Live market data and provider integrations

A GitHub Pages static site can host the frontend continuously, but it cannot guarantee 24/7 uptime, real-time prices or every feed. GitHub Actions schedules are best-effort and may be delayed or skipped. Static hosting does not securely hold secret API keys. For production-grade low-latency news, quotes, economic releases and alerts:

1. Put API keys in backend environment secrets (for example, a serverless function or private server), never in public frontend JavaScript or a public GitHub repository.
2. Build a provider adapter per feed, normalize timestamps to UTC while retaining provider timezone and event time, deduplicate articles, and store provenance.
3. Track `published_at`, `event_at`, `retrieved_at`, `provider`, `instrument`, `venue`, `latency_class`, `license`, `correction_status` and failure state.
4. Respect provider rate limits, commercial use and exchange redistribution rules. A public API does not automatically grant redistribution rights for every field.
5. Add timeouts, retry/backoff, cache bounds, circuit breakers, health checks, observability and provider-specific fallbacks.

Useful official developer references include [SEC EDGAR APIs](https://www.sec.gov/search-filings/edgar-application-programming-interfaces), [FRED API](https://fred.stlouisfed.org/docs/api/fred/), [GDELT](https://www.gdeltproject.org/), [OpenBB documentation](https://docs.openbb.co/), and [TradingView Lightweight Charts](https://github.com/tradingview/lightweight-charts). The open-source Lightweight Charts library is Apache 2.0 licensed and has its own attribution requirements; this project only links to it and does not bundle the library source.

## Scheduled snapshot behavior

The scheduled collector uses the public GDELT DOC API without keys, gathers broad macro/equity/FX/metals/energy/crypto/geopolitics queries, normalizes HTTP(S) article links, deduplicates URLs and retains the previous snapshot if a fetch fails. It commits the tracked snapshot only when article content changes; the deployed `dist/data/news-snapshot.json` carries the current check time/status. This is a best-effort news discovery feed, not a licensed exchange feed, complete newswire, or trading signal. You may disable the schedule by removing the `schedule` trigger from `.github/workflows/pages.yml`.

## Privacy

- The watchlist, theme, cached GDELT results and research journal are stored in the visitor's local browser profile.
- They are not uploaded by this app. A user can export and import a JSON backup.
- Do not commit personal backups, API tokens, credentials or private research notes into a public repository.
- External provider links, chart widgets and API requests send normal requests to the relevant third parties when used.

## License

The application code in this repository is offered under the MIT License. Third-party websites, APIs, datasets, logos, financial data and linked source content remain subject to their own terms, licenses and attribution requirements. MIT licensing of the app does not grant rights to redistribute third-party market data.

## Contributing

See `CONTRIBUTING.md` and `SECURITY.md`. Run `python scripts/build_manifest.py` after intentional source changes and then run `python scripts/validate.py` plus `python -m unittest discover -s tests -v` before submitting a pull request. Before adding a source, include a direct URL, what the source actually provides, whether access is public/freemium/paid, data delay/frequency if known, and any jurisdiction or licensing caveat. Avoid claims such as “guaranteed pump”, “sure-shot signal” or “all global news” unless the data coverage genuinely supports it.

## Social analysis and source hygiene

The Social Chart Analysis Lab opens public searches on external platforms. It does **not** scrape or ingest all X/YouTube/TradingView posts. True cross-platform feeds require provider-compliant APIs, permissions, rate limits, a backend and reliable job monitoring. Public posts can be edited/deleted, promotional or wrong; preserve publication timestamps and original evidence. Astrology/cycle claims are separated from empirical/statistical methods.

The local analyst-view ledger is stored in browser `localStorage`, not synced between devices. Export JSON/CSV for backup. Outcomes are manually recorded; accuracy and Brier score only describe the sample you captured and are not a forecast of profitability.
