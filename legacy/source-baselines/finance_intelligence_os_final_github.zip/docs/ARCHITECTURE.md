# Architecture and operating model

## Static application

`index.html` is the interactive frontend. It contains the market navigator, external source links, method search, risk/reward calculator, local watchlist and local viewpoint journal. `resources.json`, `data/market-universe.json` and `data/social-analysis-methods.json` are machine-readable catalogues.

## News snapshot pipeline

1. GitHub Actions runs `scripts/fetch_news_snapshot.py` on push/manual dispatch and on a best-effort hourly schedule.
2. The collector queries the public GDELT DOC API for broad macro, equities, FX, metals, energy, crypto and geopolitical terms.
3. It validates HTTP(S) URLs, normalizes fields, deduplicates records, records query-level success/error state, and keeps the last saved records when every query fails or comes back empty.
4. `data/news-snapshot.json` is committed only when article content changes. The current deployment artifact has `lastCheckedAt` and latest provider status even when the underlying article set did not change.
5. The frontend first shows local browser cache if it is newer; otherwise it shows the repository-published snapshot. Users can request an additional on-demand GDELT query.

## Deployment and health

- `quality.yml`: static validation, no-network unit tests and static payload build.
- `pages.yml`: builds the allow-listed `dist/` directory and deploys it through GitHub Pages.
- `link-audit.yml`: weekly/manual link audit. Its CSV artifact records successful, redirected, blocked, rate-limited, broken-looking and network-error links. HTTP 403/429 are not automatically labelled as dead.
- `sw.js`: caches the application shell and selected same-origin static files. It does not cache external news, quotes, chart widgets or third-party responses.

## What the application does not claim

- It is not a complete licensed terminal or an all-source social-media scraper.
- It does not provide authenticated X content, private Telegram messages, paid newswire feeds, live exchange quotes or broker execution by default.
- A headline, unusual volume, social post, forecast, astrology/cycle view or on-chain transfer is not a guaranteed trading signal.
- GitHub Actions scheduled jobs are best-effort; they can be delayed or skipped.

For production low-latency data, add compliant provider adapters behind a backend, store credentials in platform secrets, monitor each provider, respect licensing, and expose data provenance and freshness to the UI.
