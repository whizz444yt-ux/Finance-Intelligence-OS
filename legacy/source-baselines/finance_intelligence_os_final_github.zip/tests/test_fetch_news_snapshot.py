import sys
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import fetch_news_snapshot as news

class SnapshotTests(unittest.TestCase):
    def test_rejects_non_http_and_empty_title(self):
        self.assertIsNone(news.normalize_article({'url':'javascript:alert(1)','title':'bad'}))
        self.assertIsNone(news.normalize_article({'url':'https://example.com/news','title':'  '}))

    def test_normalizes_article_fields(self):
        item=news.normalize_article({'url':'https://example.com/a','title':' A  market  headline ','seendate':'20261026T120000Z','tone':'-1.25'},'Macro')
        self.assertIsNotNone(item)
        self.assertEqual(item['title'],'A market headline')
        self.assertEqual(item['domain'],'example.com')
        self.assertEqual(item['topic'],'Macro')
        self.assertEqual(item['tone'],-1.25)

    def test_deduplicates_urls_and_sorts(self):
        records=[
          {'url':'https://example.com/old','title':'old','seendate':'20261025T120000Z'},
          {'url':'https://example.com/new','title':'new','seendate':'20261026T120000Z'},
          {'url':'https://example.com/new/','title':'duplicate','seendate':'20261026T120000Z'},
        ]
        merged=news.merge_articles(records)
        self.assertEqual(len(merged),2)
        self.assertEqual(merged[0]['title'],'new')

    def test_fresh_results_create_snapshot(self):
        previous={'schemaVersion':1,'status':'not-yet-fetched','articles':[]}
        article={'title':'Markets rally on news','url':'https://example.com/a','seendate':'20261026T120000Z','domain':'example.com','topic':'Macro'}
        def fake(spec,timespan,max_records,timeout):
            return spec, ([article] if spec['label']=='Macro & central banks' else []), None
        with patch.object(news,'request_query',side_effect=fake):
            result,changed=news.fetch_snapshot(previous,'24h',10,1)
        self.assertTrue(changed)
        self.assertEqual(result['site']['status'],'fresh')
        self.assertEqual(result['site']['articles'][0]['url'],'https://example.com/a')

    def test_failed_provider_preserves_previous_articles(self):
        old_article={'title':'Prior article','url':'https://example.com/old','seendate':'20261025T120000Z','domain':'example.com'}
        previous={'schemaVersion':1,'status':'fresh','generatedAt':'2026-10-25T12:00:00Z','articles':[old_article]}
        def fail(spec,timespan,max_records,timeout): return spec, [], 'TimeoutError: test'
        with patch.object(news,'request_query',side_effect=fail):
            result,changed=news.fetch_snapshot(previous,'24h',10,1)
        self.assertFalse(changed)
        self.assertEqual(result['site']['status'],'stale')
        self.assertEqual(result['site']['articles'],[old_article])

if __name__=='__main__': unittest.main()
