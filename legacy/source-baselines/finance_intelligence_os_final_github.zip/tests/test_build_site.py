import sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import build_site

class BuildSiteTests(unittest.TestCase):
    def test_allowlisted_site_build_contains_runtime_files(self):
        with tempfile.TemporaryDirectory(prefix='fios-site-test-') as td:
            output=Path(td)/'dist'
            build_site.build(output)
            for relative in ['index.html','resources.json','manifest.webmanifest','icon.svg','sw.js','data/news-snapshot.json','data/market-universe.json','data/social-analysis-methods.json']:
                self.assertTrue((output/relative).is_file(), relative)
            self.assertFalse((output/'README.md').exists())
            self.assertFalse((output/'scripts').exists())

if __name__=='__main__': unittest.main()
