#!/usr/bin/env python3
"""Offline integrity checks for Finance Intelligence OS. No network needed."""
from pathlib import Path
from html.parser import HTMLParser
import hashlib, json, re, shutil, subprocess, sys, tempfile
ROOT = Path(__file__).resolve().parents[1]

class Checker(HTMLParser):
    def __init__(self):
        super().__init__(); self.ids=[]; self.links=[]; self.title=False; self.in_title=False; self.scripts=[]; self.in_script=False; self.script_attrs={}; self.script_buf=[]
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if 'id' in a: self.ids.append(a['id'])
        if tag=='a' and a.get('href') is not None: self.links.append((a.get('href',''),a.get('target'),a.get('rel','')))
        if tag=='title': self.in_title=True
        if tag=='script': self.in_script=True; self.script_attrs=a; self.script_buf=[]
    def handle_endtag(self, tag):
        if tag=='title': self.in_title=False
        if tag=='script' and self.in_script:
            self.scripts.append((self.script_attrs, ''.join(self.script_buf))); self.in_script=False
    def handle_data(self,data):
        if self.in_title and 'Finance Intelligence OS' in data: self.title=True
        if self.in_script: self.script_buf.append(data)

def fail(msg): print('FAIL:',msg); return False

def main():
    ok=True
    html_path=ROOT/'index.html'; html=html_path.read_text(encoding='utf-8')
    parser=Checker(); parser.feed(html); parser.close()
    if not parser.title: ok=fail('missing/incorrect title') and ok
    duplicates=sorted({x for x in parser.ids if parser.ids.count(x)>1})
    if duplicates: ok=fail('duplicate ids: '+', '.join(duplicates)) and ok
    idset=set(parser.ids)
    broken_hashes=sorted({h for h,_,_ in parser.links if h.startswith('#') and h[1:] not in idset})
    if broken_hashes: ok=fail('broken internal anchor links: '+', '.join(broken_hashes)) and ok
    required=['market-cockpit','instrument-navigator','x-news-desk','social-analysis-lab','salViewForm','salMathCalculate','impact-lab','live-news-hub','personal-workspace','directory','runLocalDiagnostics']
    missing=[x for x in required if x not in idset]
    if missing: ok=fail('missing expected UI ids: '+', '.join(missing)) and ok
    bad=[h for h,t,r in parser.links if t=='_blank' and ('noopener' not in r and 'noreferrer' not in r)]
    if bad: ok=fail(f'{len(bad)} target=_blank links lack noopener/noreferrer') and ok
    for href,_,_ in parser.links:
        if href.lower().startswith(('javascript:', 'data:', 'vbscript:')): ok=fail('unsafe href scheme: '+href[:100]) and ok
    data=json.loads((ROOT/'resources.json').read_text(encoding='utf-8'))
    records=data.get('resources',[])
    if data.get('count')!=len(records): ok=fail('resources.json count mismatch') and ok
    normalized=[]
    for r in records:
        if not r.get('name') or not r.get('category'): ok=fail('resource missing name/category') and ok
        if not re.match(r'^https?://',r.get('url',''),re.I): ok=fail('non-http(s) resource URL: '+str(r.get('url'))) and ok
        normalized.append(r.get('url','').rstrip('/').lower())
    if len(normalized)!=len(set(normalized)): ok=fail('duplicate normalized resource URLs remain') and ok
    social=json.loads((ROOT/'data'/'social-analysis-methods.json').read_text(encoding='utf-8'))
    if not social.get('methods') or not social.get('platforms'): ok=fail('social-analysis-methods.json missing methods/platforms') and ok
    markets=json.loads((ROOT/'data'/'market-universe.json').read_text(encoding='utf-8'))
    if markets.get('count')!=len(markets.get('markets',[])): ok=fail('market-universe count mismatch') and ok
    snapshot=json.loads((ROOT/'data'/'news-snapshot.json').read_text(encoding='utf-8'))
    if snapshot.get('schemaVersion')!=1 or not isinstance(snapshot.get('articles'),list): ok=fail('news snapshot schema invalid') and ok
    for a in snapshot.get('articles',[]):
        if not a.get('title') or not re.match(r'^https?://',a.get('url',''),re.I): ok=fail('invalid news snapshot article') and ok
    required_files=['.nojekyll','manifest.webmanifest','icon.svg','sw.js','README.md','LICENSE','CONTRIBUTING.md','SECURITY.md','scripts/fetch_news_snapshot.py','scripts/build_site.py','scripts/audit_links.py','.github/workflows/quality.yml','.github/workflows/pages.yml','.github/workflows/link-audit.yml']
    for f in required_files:
        if not (ROOT/f).exists(): ok=fail('missing package file '+f) and ok
    manifest=json.loads((ROOT/'PACKAGE-MANIFEST.json').read_text(encoding='utf-8'))
    for entry in manifest.get('files',[]):
        p=ROOT/entry['path']
        if not p.is_file(): ok=fail('manifest file missing: '+entry['path']) and ok; continue
        raw=p.read_bytes()
        if len(raw)!=entry.get('bytes'): ok=fail('manifest byte-count mismatch: '+entry['path']) and ok
        if hashlib.sha256(raw).hexdigest()!=entry.get('sha256'): ok=fail('manifest checksum mismatch: '+entry['path']) and ok
    for name in manifest.get('dynamicFiles',[]):
        if not (ROOT/name).exists(): ok=fail('manifest dynamic file missing: '+name) and ok
    # Compile inline JavaScript blocks when Node is available. JSON script blocks are skipped.
    node=shutil.which('node')
    js_count=0
    if node:
        with tempfile.TemporaryDirectory(prefix='fios-js-check-') as td:
            for i,(attrs,source) in enumerate(parser.scripts):
                typ=attrs.get('type','text/javascript').lower()
                if attrs.get('src') or not source.strip() or typ in ('application/ld+json','application/json','text/template'): continue
                path=Path(td)/f'inline-{i}.js'; path.write_text(source,encoding='utf-8')
                result=subprocess.run([node,'--check',str(path)],capture_output=True,text=True)
                js_count+=1
                if result.returncode: ok=fail(f'inline JavaScript syntax error in block {i}: '+(result.stderr or result.stdout).strip()[:500]) and ok
        sw=subprocess.run([node,'--check',str(ROOT/'sw.js')],capture_output=True,text=True)
        if sw.returncode: ok=fail('service worker JavaScript syntax error: '+sw.stderr.strip()[:500]) and ok
    else:
        print('WARN: Node not found; skipped JavaScript syntax checks.')
    print(f'HTML IDs: {len(parser.ids)} (unique: {len(idset)})')
    print(f'Anchor links checked: {len(parser.links)}; broken internal links: {len(broken_hashes)}')
    print(f'Resources: {len(records)} across {len(data.get("categories",[]))} categories')
    print(f'Market presets: {len(markets.get("markets",[]))}; inline JS blocks checked: {js_count}')
    print(f"Snapshot status: {snapshot.get('status')}; articles in tracked snapshot: {len(snapshot.get('articles', []))}")
    print('PASS' if ok else 'FAILED')
    return 0 if ok else 1
if __name__=='__main__': sys.exit(main())
