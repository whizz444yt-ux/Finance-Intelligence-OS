#!/usr/bin/env python3
"""Build the allow-listed static payload used by GitHub Pages."""
from pathlib import Path
import argparse, shutil

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_FILES = [
    Path('.nojekyll'), Path('index.html'), Path('resources.json'),
    Path('manifest.webmanifest'), Path('icon.svg'), Path('sw.js'),
    Path('data/market-universe.json'), Path('data/social-analysis-methods.json'),
    Path('data/news-snapshot.json'),
]

def build(output: Path) -> None:
    output = output.resolve()
    if output == ROOT or (ROOT in output.parents and output != (ROOT / 'dist').resolve()):
        raise ValueError('Output must be outside the repository root or exactly its dist/ build directory.')
    if output.exists():
        shutil.rmtree(output)
    output.mkdir(parents=True)
    for relative in DEFAULT_FILES:
        source = ROOT / relative
        if not source.is_file():
            raise FileNotFoundError(f'Required static site file missing: {relative}')
        target = output / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    print(f'Built static site into {output} ({len(DEFAULT_FILES)} files).')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', default='dist', help='Output directory (default: dist)')
    args = parser.parse_args()
    build(Path(args.output))
